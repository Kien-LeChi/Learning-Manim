---
name: Error when using
about: The error you encountered while using manim
title: ''
labels: ''
assignees: ''

---

### Describe the error
<!-- A clear and concise description of what you want to make. -->

### Code and Error
**Code**:
<!-- The code you run -->

**Error**:
<!-- The error traceback you get when run your code -->

### Environment
**OS System**: 
**manim version**: master <!-- make sure you are using the latest version of master branch -->
**python version**:
